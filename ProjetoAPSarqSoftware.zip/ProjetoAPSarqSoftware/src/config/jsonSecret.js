const secret = "53d1638a6369ee70db685ca31a2b0931";

export default {secret};
